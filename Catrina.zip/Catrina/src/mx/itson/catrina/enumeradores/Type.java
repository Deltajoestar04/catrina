/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package mx.itson.catrina.enumeradores;

import com.google.gson.annotations.SerializedName;

/**
 *
 * @author Admin
 */
public enum Type {
    @SerializedName("1")
    DEPOSITOS,
    @SerializedName("2")
    RETIROS,
    
}
